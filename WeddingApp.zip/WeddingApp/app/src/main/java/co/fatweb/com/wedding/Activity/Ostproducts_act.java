package co.fatweb.com.wedding.Activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import co.fatweb.com.wedding.R;

public class Ostproducts_act extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ostproducts_act);
    }
}
