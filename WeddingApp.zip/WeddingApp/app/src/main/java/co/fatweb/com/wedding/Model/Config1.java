package co.fatweb.com.wedding.Model;


public class Config1 {
    public static final String DATA_URL = "https://ido.kiwi/api/common/suburbs/1";

    //Tags used in the JSON String
    public static final String TAG_USERNAME = "id";
    public static final String TAG_NAME = "name";

    //JSON array name



}
