package co.fatweb.com.wedding.DataObject;

import com.google.gson.annotations.SerializedName;

public class RememberUser {
    @SerializedName("email")public String email;
}
