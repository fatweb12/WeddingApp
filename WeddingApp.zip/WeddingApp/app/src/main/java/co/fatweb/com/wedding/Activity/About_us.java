package co.fatweb.com.wedding.Activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import co.fatweb.com.wedding.R;

public class About_us extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
    }
}
