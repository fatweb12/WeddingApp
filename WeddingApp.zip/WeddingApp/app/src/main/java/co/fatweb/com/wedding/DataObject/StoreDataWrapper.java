package co.fatweb.com.wedding.DataObject;

import java.util.List;

public class StoreDataWrapper {
    private List<StoreData> name;

    public List<StoreData> getName() {
        return name;
    }

    public void setName(List<StoreData> name) {
        this.name = name;
    }
}
