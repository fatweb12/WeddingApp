package co.fatweb.com.wedding.Adapter;

public interface PaginationAdapterCallback {
    void retryPageLoad();
}
